﻿// For more information see https://aka.ms/fsharp-console-apps

printfn "Betöltés..."
open System
open System.IO

let dtob (dszam:int)=
    let mutable bszam = ""
    let mutable sz = 0
    let mutable x = 128
    sz <- dszam
    
    
      
    for i = 0 to 7 do
      if sz >= x then
         sz <- sz - x
         x <- x / 2
         bszam <- bszam + "1"
      else
          x <- x / 2
          bszam <- bszam + "0"      
    bszam

let btod (bszam:string) =
    let mutable bsz = ""
    let mutable dsz = 0
    let mutable x = 128
    let mutable y = 0

    bsz <- bszam
    for i=0 to (bsz.Length-1) do 
        y <- int bsz[i]  - int '0'
        dsz <- dsz + (x*y)
        x <- x/2
   
    dsz

let kizvagy (be:string) (paswd:string) = 
    let mutable bem =""
    let mutable jsz ="" 
    let mutable er =""
    bem <- be
    jsz <- paswd

    for i=0 to (bem.Length-1) do
      if not (bem[i] = jsz[i]) then
        er <- er + "1"
      else
        er <- er + "0"
    er

let kkar = File.ReadAllText("kartar.txt")
let mutable ok = false
let mutable valasz = ""
let mutable st = "¸"
let mutable szov = ""
let mutable sor = ""
let mutable fbe = ""

let mutable phosz = 0
let mutable bszov = ""
let mutable bpas = ""
let mutable bkod = ""

let mutable paswd = ""
let mutable fadat = [|"";""|] 





while not ok do
        Console.Clear()
        printfn "Encryptor"
        printfn "========="
        printfn ""
        printfn "1. Kódolás"
        printfn "2. Dekódolás"
        printfn "3. Kilépés"
        printfn "============"
        printf "Kérem válasszon: "
        valasz <- Console.ReadLine()

        if (valasz = "1") || (valasz = "2") || (valasz = "3") then
          ok <- true
        else
          printfn "Csak 1-et vagy 2-t vagy 3-at írhat be, próbálja újból :/"
          Console.ReadKey() |> ignore

Console.Clear()
ok <- false
if valasz = "1" then
  printfn "Encryptor: Kódolás"
  printfn "=================="
  printfn ""
  
  while not ok do
    printfn "1. Kódolandó szöveg beolvasása képernyőről"
    printfn "2. Kódolandó szöveg beolvasása fájlból"
    printfn "==========================================="
    printf "Kérem válasszon: "
    valasz <- Console.ReadLine()
    
    match valasz with
    | "1" -> 
             let mutable kkod = 0
             //let mutable phosz = 0


             ok <- true
             Console.Clear()
             printfn "Kódolás Képernyőről"
             printfn "==========================================="
             printfn "Gépelje le a kódolni kívánt szöveget,írjon '-*-' ha le szeretné zárni a szöveget: "
             while ok do
               sor <- Console.ReadLine()
               if not (sor = "-*-") then
                  szov <- szov + sor + st
               else
                  ok <- false
             
             printfn ""
             printf "Kérném a titkosító kulcsot: "
             paswd <- Console.ReadLine()
             printfn ""
             (*---------------------------------------------------------*)
             for i = 0 to (szov.Length-1) do            
                if phosz > (paswd.Length-1) then                
                    phosz <- 0

                bszov <- dtob (int szov[i])
                bpas <-  dtob (int paswd[phosz])
                
                bkod <-  kizvagy (bszov) (bpas)

                printf"%d " (btod bkod)


                phosz <- phosz + 1              
             Console.ReadKey() |> ignore
    | "2" -> 
             ok <- true
             printfn "Kódolás Fájlból"


    | _ -> 
           printfn "Csak 1-et vagy 2-t írhat be, próbálja újból :/"
           Console.ReadKey() |> ignore
           


  Console.ReadKey() |> ignore
elif valasz = "2" then
  printfn "Encryptor: Dekódolás"
  printfn "===================="
  printfn ""
  let mutable be = 0
  let mutable bekod = ""
  let mutable er =0
  let mutable ki = ""
  //let mutable kodtomb = ""

  
  let mutable bpaswd = ""

  printf "Kérném a kódot: "
  //bekod <- "16 4 1 19 7 30 20" 
  bekod <- (Console.ReadLine())

  let kodtomb = bekod.Split(' ') |> Array.map int
  
  
  //be <- int bekod
  printf "Kérném a jelszót: "
  paswd <- Console.ReadLine()
  (*--------------------------*)
  phosz <-0
  
  for i = 0 to (kodtomb.Length-1) do
      if phosz > (paswd.Length-1) then
          phosz <-0
      
      bkod <- dtob kodtomb[i]
      bpas <- dtob (int paswd[phosz])
      bszov <-  kizvagy (bkod) (bpas)
      
      er <- btod bszov

      ki <- ki + string(char er)

      phosz <- phosz + 1

  
  
  
  
  for i = 0 to (ki.Length-1) do
    if ki[i] = '¸' then
      printfn ""
    else
      printf "%c" ki[i]
  Console.ReadKey() |> ignore


  
       
          



Console.ReadKey() |> ignore

    
    
    (*let lines = File.ReadAllLines("be.txt")
  
  printfn "A szöveg: "
  for line in lines do
    fbe <- fbe + line + "¸"

  for i = 0 to (fbe.Length-1) do
    if fbe[i] = '¸' then
      printfn ""
    else
      printf "%c" fbe[i]  *)


(*for i = 0 to (szov.Length-1) do
              if szov[i] = char st then
                printfn ""
              else
                printf "%c" szov[i]*)